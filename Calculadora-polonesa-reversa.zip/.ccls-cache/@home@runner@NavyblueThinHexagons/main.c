#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX 100 // tamanho máximo da expressão
#define TAM 100 // tamanho máximo da pilha

float pilha[MAX];
int topo = -1;

float x = 0;
float y = 0;
float z = 0;
float t = 0;

void push(float valor) {
    if (topo == MAX - 1) {
        printf("Erro: pilha cheia!\n");
        exit(EXIT_FAILURE);
    } else {
        topo++;
        pilha[topo] = valor;
        z = y;
        y = x;
        x = valor;
        printf("X=%.2f Y=%.2f Z=%.2f T=%.2f\n", x, y, z, t);
    }
}

float pop() {
    if (topo == -1) {
        printf("Erro: pilha vazia!\n");
        exit(EXIT_FAILURE);
    } else {
        float valor = pilha[topo];
        topo--;
        t = z;
        z = y;
        y = x;
        x = valor;
        printf("X=%.2f Y=%.2f Z=%.2f T=%.2f\n", x, y, z, t);
        return valor;
    }
}

int pilha_vazia() {
    if (topo == -1) {
        return 1;
    } else {
        return 0;
    }
}

void limpar_pilha() {
    topo = -1;
    x = y = z = t = 0;
    printf("X=%.2f Y=%.2f Z=%.2f T=%.2f\n", x, y, z, t);
}

void mostrar_pilha() {
    printf("Pilha: ");
    for (int i = topo; i >= 0; i--) {
        printf("%.2f ", pilha[i]);
    }
    printf("\n");
}

void operacao(char op) {
    float valor1, valor2;
    valor2 = pop();
    valor1 = pop();
    switch (op) {
        case '+':
            push(valor1 + valor2);
            break;
        case '-':
            push(valor1 - valor2);
            break;
        case '*':
            push(valor1 * valor2);
            break;
        case '/':
            if (valor2 == 0) {
                printf("Erro: divisao por zero!\n");
                exit(EXIT_FAILURE);
            }
            push(valor1 / valor2);
            break;
    }
}

int main() {
    char expr[MAX]; // declara a expressão que o usuário irá inserir
    int i = 0;
    float valor;
    char continuar = 's';

    while (continuar == 's') { // Loop para permitir várias contas
        printf("Digite uma expressao em notacao polonesa reversa: ");
        fgets(expr, MAX, stdin); // lê a expressão inserida pelo usuário
        while (expr[i] != '\0' && expr[i] != '\n') { // percorre a expressão
            if (isdigit(expr[i])) { // se for um dígito, empilha o valor
                valor = 0;
                while (isdigit(expr[i])) {
                    valor = valor * 10 + (expr[i] - '0');
                    i++;
                }
                push(valor);
            } else if (expr[i] == '+' || expr[i] == '-' || expr[i] == '*' || expr[i] == '/') { // se for um operador
                operacao(expr[i]);
i++;
} else if (expr[i] == ' ') { // se for um espaço em branco, ignora
i++;
} else { // se for um caracter inválido, exibe mensagem de erro e encerra o programa
printf("Erro: caracter invalido na expressao!\n");
exit(EXIT_FAILURE);
}
}
printf("Resultado: %.2f\n", pop());
mostrar_pilha();
printf("Deseja fazer outra conta? (s/n) ");
scanf("%c", &continuar);
getchar(); // consome o caractere de nova linha deixado pelo scanf
limpar_pilha();
i = 0;
}
return 0;
}